from flask import Flask, render_template, request, Response, send_file
import time, json

app = Flask(__name__)
results = []

def get_proxies(mode):
    if mode == "auto":
        return ["proxy1", "proxy2", "proxy3"]
    return []

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/stream", methods=["POST"])
def stream():
    data = request.json
    base_urls = data.get("base_urls", [])
    wordlist = data.get("wordlist", "").split("\n")
    proxy_mode = data.get("proxy_mode", "none")
    proxies = get_proxies(proxy_mode)
    results.clear()
    start_time = time.time()

    def generate():
        count = 0
        for base_url in base_urls:
            for word in wordlist:
                proxy = proxies[count % len(proxies)] if proxies else "none"
                guessed_url = base_url.replace("{{var1}}", word)
                status = 200 if "admin" in guessed_url else 404
                result = {
                    "url": guessed_url,
                    "status": status,
                    "proxy": proxy,
                    "base_url": base_url
                }
                results.append(result)
                count += 1
                time.sleep(0.1)
                yield f"data: {json.dumps(result)}\n\n"
        yield f"data: {json.dumps({'done': True, 'elapsed': round(time.time() - start_time, 2)})}\n\n"

    return Response(generate(), mimetype='text/event-stream')

@app.route("/download-results")
def download_results():
    html = "<html><head><style>body{background:#111;color:#0f0;font-family:monospace;}table{width:100%;border-collapse:collapse;}td,th{border:1px solid #0f0;padding:5px;}</style></head><body><h2>Results</h2><table><tr><th>Base URL</th><th>Guessed URL</th><th>Status</th><th>Proxy</th></tr>"
    for r in results:
        html += f"<tr><td>{r['base_url']}</td><td>{r['url']}</td><td>{r['status']}</td><td>{r['proxy']}</td></tr>"
    html += "</table></body></html>"
    with open("results.html", "w") as f:
        f.write(html)
    return send_file("results.html", as_attachment=True)